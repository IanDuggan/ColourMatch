package project.merge;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

import project.merge.SQL.DatabaseHelper;
import project.merge.adapter.CustomListAdapter;
import project.merge.model.Items;
import project.merge.model.User;

public class showScoreboard extends AppCompatActivity {

    public String username;
    public int score;
    public boolean gamePlayed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_scoreboard);
        DatabaseHelperScore dbhelper = new DatabaseHelperScore((this));
        Intent intent = getIntent();
        username = intent.getStringExtra("Username");
        score = intent.getIntExtra("Score",score);
        gamePlayed = intent.getBooleanExtra("Played",gamePlayed);

        String scoreString = score + "";
        Items user = new Items();
        user.setScore(scoreString);
        user.setName(username);
        if (gamePlayed)
        {
            dbhelper.addScore(user);
        }

        fillListView();

    }
    public void fillListView(){
        ListView myListView = findViewById(R.id.list);
        DatabaseHelperScore dbhelper = new DatabaseHelperScore(this);
        ArrayList<Items> itemsList = dbhelper.getAllScores();

        CustomListAdapter myAdapter = new CustomListAdapter(itemsList,this);
        myListView.setAdapter(myAdapter);
    }
}
